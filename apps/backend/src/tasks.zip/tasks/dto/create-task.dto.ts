// export class CreateTaskDto {
//   name: string;
//   description: string;
//   priority: number;
//   status: string;
//   dueDate: Date;
//   assignedTo: string;
//   assignedBy: string;
//   assignedOn: Date;
// }
import { IsString, IsNotEmpty, IsOptional, IsEnum, IsDateString, IsNumber, Min, Max, MaxLength } from 'class-validator';
import { TaskStatus } from '../enum/task-status.enum';

/**
 * DTO for creating a new task
 * Only admin users can create tasks and assign them to standard users
 */
export class CreateTaskDto {
  @IsNotEmpty()
  @IsString()
  @MaxLength(100)
  title: string;

  @IsNotEmpty()
  @IsString()
  @MaxLength(500)
  description: string;

  @IsOptional()
  @IsEnum(TaskStatus)
  status?: TaskStatus = TaskStatus.Pending;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(5)
  priority?: number = 1; // 1 = Low, 5 = High

  @IsOptional()
  @IsDateString()
  dueDate?: string;

  @IsNotEmpty()
  @IsNumber()
  assignedToUserId: number; // ID of the user to assign the task to
}

/**
 * DTO for assigning a task to a user
 * Only admin users can assign tasks
 */
export class AssignTaskDto {
  @IsNotEmpty()
  @IsNumber()
  assignedToUserId: number;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  assignmentNote?: string;
}