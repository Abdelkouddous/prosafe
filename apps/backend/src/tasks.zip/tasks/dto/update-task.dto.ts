import { IsString, IsOptional, IsEnum, IsDateString, IsNumber, Min, Max, MaxLength, IsBoolean } from 'class-validator';
import { TaskStatus } from '../enum/task-status.enum';

/**
 * DTO for updating a task
 * Admins can update all fields, users can only update status
 */
export class UpdateTaskDto {
  @IsOptional()
  @IsString()
  @MaxLength(100)
  title?: string;

  @IsOptional()
  @IsString()
  @MaxLength(500)
  description?: string;

  @IsOptional()
  @IsEnum(TaskStatus)
  status?: TaskStatus;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(5)
  priority?: number;

  @IsOptional()
  @IsDateString()
  dueDate?: string;

  @IsOptional()
  @IsBoolean()
  isCompleted?: boolean;
}
