import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
  Request,
  ParseIntPipe,
  HttpStatus,
  HttpCode,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { TasksService } from './tasks.service';
import { CreateTaskDto, AssignTaskDto } from './dto/create-task.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { TaskStatus } from './enum/task-status.enum';
import { Role } from '../users/enums/role.enum';

/**
 * Tasks Controller
 * Handles task management with admin-only creation and assignment
 * Standard users can view and update their assigned tasks
 */
@Controller('tasks')
export class TasksController {
  constructor(private readonly tasksService: TasksService) {}

  /**
   * Create a new task (admin only)
   * POST /tasks
   * @param createTaskDto - Task creation data
   * @param req - Request object containing admin user info
   * @returns Created task
   */
  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() createTaskDto: CreateTaskDto, @Request() req) {
    const adminId = req.user?.id;
    if (!adminId) {
      throw new BadRequestException('User not authenticated');
    }

    const task = await this.tasksService.create(createTaskDto, adminId);
    
    return {
      message: 'Task created successfully',
      task,
    };
  }

  /**
   * Get all tasks with optional filtering
   * GET /tasks
   * @param userId - Optional user ID filter
   * @param status - Optional status filter
   * @param req - Request object containing user info
   * @returns Array of tasks
   */
  @Get()
  async findAll(
    @Query('userId') userId?: string,
    @Query('status') status?: TaskStatus,
    @Request() req?,
  ) {
    const currentUserId = req?.user?.id;
    const currentUserRoles = req?.user?.roles || [];
    
    // Validate status enum if provided
    if (status && !Object.values(TaskStatus).includes(status)) {
      throw new BadRequestException('Invalid task status');
    }

    // If not admin, users can only see their own tasks
    let filterUserId = userId ? parseInt(userId) : undefined;
    
    if (!currentUserRoles.includes(Role.admin)) {
      filterUserId = currentUserId; // Force filter to current user for non-admins
    }

    const tasks = await this.tasksService.findAll(filterUserId, status);
    
    return {
      message: 'Tasks retrieved successfully',
      tasks,
      count: tasks.length,
    };
  }

  /**
   * Get tasks assigned to current user
   * GET /tasks/my-tasks
   * @param req - Request object containing user info
   * @returns User's assigned tasks
   */
  @Get('my-tasks')
  async getMyTasks(@Request() req) {
    const userId = req.user?.id;
    if (!userId) {
      throw new BadRequestException('User not authenticated');
    }

    const tasks = await this.tasksService.findTasksForUser(userId);
    
    return {
      message: 'Your tasks retrieved successfully',
      tasks,
      count: tasks.length,
    };
  }

  /**
   * Get tasks created by current admin
   * GET /tasks/created-by-me
   * @param req - Request object containing admin user info
   * @returns Tasks created by admin
   */
  @Get('created-by-me')
  async getTasksCreatedByMe(@Request() req) {
    const adminId = req.user?.id;
    const userRoles = req.user?.roles || [];

    if (!adminId) {
      throw new BadRequestException('User not authenticated');
    }

    if (!userRoles.includes(Role.admin)) {
      throw new ForbiddenException('Only admin users can view created tasks');
    }

    const tasks = await this.tasksService.findTasksCreatedByAdmin(adminId);
    
    return {
      message: 'Tasks created by you retrieved successfully',
      tasks,
      count: tasks.length,
    };
  }

  /**
   * Get task statistics (admin only)
   * GET /tasks/stats
   * @param req - Request object containing admin user info
   * @returns Task statistics
   */
  @Get('stats')
  async getTaskStats(@Request() req) {
    const userRoles = req.user?.roles || [];

    if (!userRoles.includes(Role.admin)) {
      throw new ForbiddenException('Only admin users can view task statistics');
    }

    const stats = await this.tasksService.getTaskStats();
    
    return {
      message: 'Task statistics retrieved successfully',
      stats,
    };
  }

  /**
   * Get a single task by ID
   * GET /tasks/:id
   * @param id - Task ID
   * @param req - Request object containing user info
   * @returns Task data
   */
  @Get(':id')
  async findOne(@Param('id', ParseIntPipe) id: number, @Request() req) {
    const task = await this.tasksService.findOne(id);
    const currentUserId = req?.user?.id;
    const currentUserRoles = req?.user?.roles || [];

    // Check if user has permission to view this task
    const isAdmin = currentUserRoles.includes(Role.admin);
    const isAssignedUser = task.assignedTo.id === currentUserId;
    const isCreator = task.createdBy.id === currentUserId;

    if (!isAdmin && !isAssignedUser && !isCreator) {
      throw new ForbiddenException('You can only view tasks assigned to you or created by you');
    }

    return {
      message: 'Task retrieved successfully',
      task,
    };
  }

  /**
   * Update a task
   * PATCH /tasks/:id
   * @param id - Task ID
   * @param updateTaskDto - Update data
   * @param req - Request object containing user info
   * @returns Updated task
   */
  @Patch(':id')
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateTaskDto: UpdateTaskDto,
    @Request() req,
  ) {
    const userId = req.user?.id;
    if (!userId) {
      throw new BadRequestException('User not authenticated');
    }

    const updatedTask = await this.tasksService.update(id, updateTaskDto, userId);
    
    return {
      message: 'Task updated successfully',
      task: updatedTask,
    };
  }

  /**
   * Mark task as completed
   * PATCH /tasks/:id/complete
   * @param id - Task ID
   * @param req - Request object containing user info
   * @returns Completed task
   */
  @Patch(':id/complete')
  async markAsCompleted(@Param('id', ParseIntPipe) id: number, @Request() req) {
    const userId = req.user?.id;
    if (!userId) {
      throw new BadRequestException('User not authenticated');
    }

    const completedTask = await this.tasksService.markAsCompleted(id, userId);
    
    return {
      message: 'Task marked as completed successfully',
      task: completedTask,
    };
  }

  /**
   * Assign task to a different user (admin only)
   * PATCH /tasks/:id/assign
   * @param id - Task ID
   * @param assignTaskDto - Assignment data
   * @param req - Request object containing admin user info
   * @returns Updated task
   */
  @Patch(':id/assign')
  async assignTask(
    @Param('id', ParseIntPipe) id: number,
    @Body() assignTaskDto: AssignTaskDto,
    @Request() req,
  ) {
    const adminId = req.user?.id;
    if (!adminId) {
      throw new BadRequestException('User not authenticated');
    }

    const updatedTask = await this.tasksService.assignTask(id, assignTaskDto, adminId);
    
    return {
      message: 'Task reassigned successfully',
      task: updatedTask,
    };
  }

  /**
   * Delete a task (admin only)
   * DELETE /tasks/:id
   * @param id - Task ID
   * @param req - Request object containing admin user info
   * @returns Success message
   */
  @Delete(':id')
  async remove(@Param('id', ParseIntPipe) id: number, @Request() req) {
    const adminId = req.user?.id;
    if (!adminId) {
      throw new BadRequestException('User not authenticated');
    }

    await this.tasksService.remove(id, adminId);
    
    return {
      message: 'Task deleted successfully',
    };
  }
}
