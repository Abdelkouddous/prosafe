import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { TaskStatus } from '../enum/task-status.enum';

/**
 * Task Entity
 * Represents a task that can be created by admins and assigned to standard users
 */
@Entity()
export class Task {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 100 })
  title: string;

  @Column({ length: 500 })
  description: string;

  @Column({ type: 'enum', enum: TaskStatus, default: TaskStatus.Pending })
  status: TaskStatus;

  @Column({ default: 1 })
  priority: number; // 1 = Low, 5 = High

  @Column({ default: false })
  isCompleted: boolean;

  @Column({ type: 'timestamp', nullable: true })
  dueDate: Date;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  /**
   * The admin user who created this task
   */
  @ManyToOne(() => User, (user) => user.createdTasks, { eager: true })
  createdBy: User;

  /**
   * The standard/premium user to whom this task is assigned
   */
  @ManyToOne(() => User, (user) => user.assignedTasks, { eager: true })
  assignedTo: User;
}
