import { Injectable, NotFoundException, ForbiddenException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateTaskDto, AssignTaskDto } from './dto/create-task.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { Task } from './entities/task.entity';
import { User } from '../users/entities/user.entity';
import { TaskStatus } from './enum/task-status.enum';
import { Role } from '../users/enums/role.enum';

/**
 * Tasks Service
 * Handles task management with admin-only creation and assignment
 * Standard users can view and update their assigned tasks
 */
@Injectable()
export class TasksService {
  constructor(
    @InjectRepository(Task)
    private readonly taskRepository: Repository<Task>,
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  /**
   * Create a new task (admin only)
   * @param createTaskDto - Task creation data
   * @param adminId - ID of the admin creating the task
   * @returns Created task
   */
  async create(createTaskDto: CreateTaskDto, adminId: number): Promise<Task> {
    // Verify admin user exists and has admin role
    const admin = await this.userRepository.findOne({
      where: { id: adminId },
    });

    if (!admin) {
      throw new NotFoundException('Admin user not found');
    }

    if (!admin.roles.includes(Role.admin)) {
      throw new ForbiddenException('Only admin users can create tasks');
    }

    // Verify assigned user exists and is active
    const assignedUser = await this.userRepository.findOne({
      where: { id: createTaskDto.assignedToUserId, isActive: true },
    });

    if (!assignedUser) {
      throw new NotFoundException('Assigned user not found or inactive');
    }

    // Create task
    const task = this.taskRepository.create({
      title: createTaskDto.title,
      description: createTaskDto.description,
      status: createTaskDto.status || TaskStatus.Pending,
      priority: createTaskDto.priority || 1,
      dueDate: createTaskDto.dueDate ? new Date(createTaskDto.dueDate) : null,
      createdBy: admin,
      assignedTo: assignedUser,
    });

    return await this.taskRepository.save(task);
  }

  /**
   * Find all tasks with optional filtering
   * @param userId - Optional user ID filter
   * @param status - Optional status filter
   * @returns Array of tasks
   */
  async findAll(userId?: number, status?: TaskStatus): Promise<Task[]> {
    const queryBuilder = this.taskRepository
      .createQueryBuilder('task')
      .leftJoinAndSelect('task.createdBy', 'createdBy')
      .leftJoinAndSelect('task.assignedTo', 'assignedTo');

    if (userId) {
      queryBuilder.where('task.assignedTo.id = :userId', { userId });
    }

    if (status) {
      queryBuilder.andWhere('task.status = :status', { status });
    }

    queryBuilder.orderBy('task.createdAt', 'DESC');

    return await queryBuilder.getMany();
  }

  /**
   * Find a single task by ID
   * @param id - Task ID
   * @returns Task
   */
  async findOne(id: number): Promise<Task> {
    const task = await this.taskRepository.findOne({
      where: { id },
      relations: ['createdBy', 'assignedTo'],
    });

    if (!task) {
      throw new NotFoundException(`Task with ID ${id} not found`);
    }

    return task;
  }

  /**
   * Update a task
   * @param id - Task ID
   * @param updateTaskDto - Update data
   * @param userId - ID of the user updating the task
   * @returns Updated task
   */
  async update(id: number, updateTaskDto: UpdateTaskDto, userId: number): Promise<Task> {
    const task = await this.findOne(id);
    const user = await this.userRepository.findOne({ where: { id: userId } });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const isAdmin = user.roles.includes(Role.admin);
    const isAssignedUser = task.assignedTo.id === userId;
    const isCreator = task.createdBy.id === userId;

    // Check permissions
    if (!isAdmin && !isAssignedUser && !isCreator) {
      throw new ForbiddenException('You can only update tasks assigned to you or created by you');
    }

    // Non-admin users can only update status and completion
    if (!isAdmin) {
      const allowedFields = ['status', 'isCompleted'];
      const providedFields = Object.keys(updateTaskDto);
      const hasDisallowedFields = providedFields.some(field => !allowedFields.includes(field));

      if (hasDisallowedFields) {
        throw new ForbiddenException('Standard users can only update task status and completion');
      }
    }

    // Update task
    Object.assign(task, updateTaskDto);

    if (updateTaskDto.dueDate) {
      task.dueDate = new Date(updateTaskDto.dueDate);
    }

    return await this.taskRepository.save(task);
  }

  /**
   * Mark task as completed
   * @param id - Task ID
   * @param userId - ID of the user marking the task
   * @returns Updated task
   */
  async markAsCompleted(id: number, userId: number): Promise<Task> {
    const task = await this.findOne(id);
    const user = await this.userRepository.findOne({ where: { id: userId } });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const isAdmin = user.roles.includes(Role.admin);
    const isAssignedUser = task.assignedTo.id === userId;

    if (!isAdmin && !isAssignedUser) {
      throw new ForbiddenException('You can only complete tasks assigned to you');
    }

    task.isCompleted = true;
    task.status = TaskStatus.Completed;

    return await this.taskRepository.save(task);
  }

  /**
   * Assign task to a different user (admin only)
   * @param id - Task ID
   * @param assignTaskDto - Assignment data
   * @param adminId - ID of the admin assigning the task
   * @returns Updated task
   */
  async assignTask(id: number, assignTaskDto: AssignTaskDto, adminId: number): Promise<Task> {
    const admin = await this.userRepository.findOne({ where: { id: adminId } });

    if (!admin || !admin.roles.includes(Role.admin)) {
      throw new ForbiddenException('Only admin users can assign tasks');
    }

    const task = await this.findOne(id);
    const newAssignedUser = await this.userRepository.findOne({
      where: { id: assignTaskDto.assignedToUserId, isActive: true },
    });

    if (!newAssignedUser) {
      throw new NotFoundException('Assigned user not found or inactive');
    }

    task.assignedTo = newAssignedUser;

    return await this.taskRepository.save(task);
  }

  /**
   * Delete a task (admin only)
   * @param id - Task ID
   * @param adminId - ID of the admin deleting the task
   */
  async remove(id: number, adminId: number): Promise<void> {
    const admin = await this.userRepository.findOne({ where: { id: adminId } });

    if (!admin || !admin.roles.includes(Role.admin)) {
      throw new ForbiddenException('Only admin users can delete tasks');
    }

    const task = await this.findOne(id);
    await this.taskRepository.remove(task);
  }

  /**
   * Find tasks assigned to a specific user
   * @param userId - User ID
   * @returns Array of tasks
   */
  async findTasksForUser(userId: number): Promise<Task[]> {
    return await this.taskRepository.find({
      where: { assignedTo: { id: userId } },
      relations: ['createdBy', 'assignedTo'],
      order: { createdAt: 'DESC' },
    });
  }

  /**
   * Find tasks created by a specific admin
   * @param adminId - Admin ID
   * @returns Array of tasks
   */
  async findTasksCreatedByAdmin(adminId: number): Promise<Task[]> {
    return await this.taskRepository.find({
      where: { createdBy: { id: adminId } },
      relations: ['createdBy', 'assignedTo'],
      order: { createdAt: 'DESC' },
    });
  }

  /**
   * Get task statistics (admin only)
   * @returns Task statistics
   */
  async getTaskStats(): Promise<any> {
    const totalTasks = await this.taskRepository.count();
    const pendingTasks = await this.taskRepository.count({ where: { status: TaskStatus.Pending } });
    const inProgressTasks = await this.taskRepository.count({ where: { status: TaskStatus.InProgress } });
    const completedTasks = await this.taskRepository.count({ where: { status: TaskStatus.Completed } });
    const overdueTasks = await this.taskRepository.count({
      where: {
        dueDate: { $lt: new Date() } as any,
        isCompleted: false,
      },
    });

    return {
      total: totalTasks,
      pending: pendingTasks,
      inProgress: inProgressTasks,
      completed: completedTasks,
      overdue: overdueTasks,
      completionRate: totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0,
    };
  }
}
