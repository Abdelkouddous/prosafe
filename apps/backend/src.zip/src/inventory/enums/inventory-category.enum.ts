export enum InventoryCategory {
  ELECTRONICS = 'electronics',
  OFFICE_SUPPLIES = 'office_supplies',
  FURNITURE = 'furniture',
  SAFETY_EQUIPMENT = 'safety_equipment',
  TOOLS = 'tools',
  CONSUMABLES = 'consumables',
  OTHER = 'other'
}