export enum AlertType {
  SECURITY = 'security',
  SYSTEM = 'system',
  NETWORK = 'network',
  USER_ACTIVITY = 'user_activity',
  COMPLIANCE = 'compliance',
  PERFORMANCE = 'performance'
}