export enum AlertStatus {
  UNRESOLVED = 'unresolved',
  INVESTIGATING = 'investigating',
  RESOLVED = 'resolved',
  DISMISSED = 'dismissed',
}
