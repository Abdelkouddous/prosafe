export enum IncidentType {
  SAFETY = 'safety',
  SECURITY = 'security',
  HR_VIOLATION = 'hr_violation'
}