export enum Role {
  admin = 'admin',
  pending = 'pending',
  standard = 'standard',
  premium = 'premium',
}
